package com.rigel.rigel_fyp_project

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
