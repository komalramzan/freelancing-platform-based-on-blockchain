# Blockchain Based Freelancing Platform
Blockchain technology has immensely effect the
payment methods which not only eliminates the necessity of a trusted third party but also provides a
distributed shared ledger. This technology will also make freelancing more flexible where you can often
work full- or part-time on projects of your choice, at the hours that are convenient for you. We propose
an idea where all freelance transactions will get stored on a Blockchain. There will be no middle man in
this system hence making it more secure. This will be a portal to find
short-term freelance work where clients can upload their projects which freelancers can browse through
and pick up. Before a project is assigned, the client will have to deposit the charges in a smart contract.
After a project is assigned, any changes to the contract can be done only if it is authorized by both the
sides.

[![Doc1-2.jpg](https://i.postimg.cc/QdGL6zyK/Doc1-2.jpg)](https://postimg.cc/MvDrH9xz)
